Eternal Champions (Mega Drive) v1.0
Traducción al español por PeterDelta
https://peterdelta.blogspot.com/

--------------
Instrucciones:
--------------
* Para parchear la rom puedes usar LunarIPS o Floating IPS.
* Si el emulador lo soporta, pon el .ips en la misma carpeta que el juego.

* Archivo utilizado:
Eternal Champions (USA).md
MD5: BDE8B2396241AA27463CA875E604B8D3
SHA1: 5E978217C10B679A42D7D2966A4CCB77E1715962
CRC32: 48F1A42E

------
Notas:
------
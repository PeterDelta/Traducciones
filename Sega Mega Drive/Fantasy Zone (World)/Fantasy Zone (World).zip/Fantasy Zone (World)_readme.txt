Fantasy Zone (Mega Drive Mini II) v1.0
Traducción al español por PeterDelta
https://peterdelta.blogspot.com/

--------------
Instrucciones:
--------------
* Para parchear la rom puedes usar LunarIPS o Floating IPS.
* Si el emulador lo soporta, pon el .ips en la misma carpeta que el juego.

* Archivo utilizado:
Fantasy Zone (World).md
MD5: CFADE962C35259F42AABD2B1072F6B65
SHA1: 51DB3D252BE61F9949B6A841B6EB23A5FE288A32
CRC32: DA31F3AC

------
Notas:
------
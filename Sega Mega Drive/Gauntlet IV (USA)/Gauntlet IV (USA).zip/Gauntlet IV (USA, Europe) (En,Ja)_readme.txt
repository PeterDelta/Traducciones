Gauntlet IV (Mega Drive) v1.0
Traducción al español por PeterDelta
https://peterdelta.blogspot.com/

--------------
Instrucciones:
--------------
* Para parchear la rom puedes usar LunarIPS o Floating IPS.
* Si el emulador lo soporta, pon el .ips en la misma carpeta que el juego.

* Archivo utilizado:
Gauntlet IV (USA, Europe) (En,Ja).md
MD5: 840F9F6FD4F22686B89CFD9A9ADE105A
SHA1: 26C26EE2BB9571D51537D9328A5FD2A91B4E9DC1
CRC32: 3BF46DCE

------
Notas:
------